"""Low-shot PIED classification with complete ground-truth validation."""

from __future__ import annotations

import json
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from qiskit import transpile
from qiskit_aer import AerSimulator

from finite_shot_study import dct1_coefficients, design, is_prime
from pied.core import analytic_fourier_coefficient_uniform, analytic_purity, build_swap_test_circuit, prime_bound_uniform

SEED = 20260919
SHOT_BUDGET = {4: 3_000, 8: 5_000, 16: 10_000}


def run(d: int, backend: AerSimulator) -> dict:
    spec = design(d)
    p = spec["partitions"]
    M = SHOT_BUDGET[d]
    x = np.linspace(0, np.pi, p)
    t0 = time.perf_counter()
    circuits = [build_swap_test_circuit(d, float(t)) for t in x]
    transpiled = transpile(circuits, backend, optimization_level=3, seed_transpiler=SEED)
    result = backend.run(transpiled, shots=M, seed_simulator=SEED + d).result()
    sampled = np.array([2 * result.get_counts(i).get("0", 0) / M - 1 for i in range(p)])
    elapsed = time.perf_counter() - t0

    exact_trace = np.asarray(analytic_purity(d, x))
    estimates_all = dct1_coefficients(sampled)
    modes = np.arange(2, 2 * (d - 1) + 1)
    exact = np.array([analytic_fourier_coefficient_uniform(d, int(n)) for n in modes])
    bound = np.array([prime_bound_uniform(d, int(n)) for n in modes])

    N = p - 1
    endpoint = np.ones(p); endpoint[[0, -1]] = .5
    var_trace = (1 - exact_trace**2) / M
    se = np.array([
        np.sqrt(np.sum(((2 / N) * endpoint * np.cos(n * np.pi * np.arange(p) / N))**2 * var_trace))
        for n in modes
    ])

    # Numeric version of alpha_n=B_n: use half the globally smallest
    # prime/composite separation.  This rule uses d only, not the true label.
    threshold = spec["minimum_gap"] / 2
    estimates = estimates_all[modes]
    predicted_prime = np.abs(estimates - bound) < threshold
    actual_prime = np.array([is_prime(int(n)) for n in modes])
    rows = []
    for i, n in enumerate(modes):
        rows.append({
            "n": int(n), "actual": "prime" if actual_prime[i] else "composite",
            "predicted": "prime" if predicted_prime[i] else "composite",
            "correct": bool(actual_prime[i] == predicted_prime[i]),
            "estimate": float(estimates[i]), "analytic": float(exact[i]),
            "B_n": float(bound[i]), "standard_error": float(se[i]),
        })
    tp = int(np.sum(predicted_prime & actual_prime))
    fp = int(np.sum(predicted_prime & ~actual_prime))
    tn = int(np.sum(~predicted_prime & ~actual_prime))
    fn = int(np.sum(~predicted_prime & actual_prime))
    return {
        "dimension": d, "partitions": p, "shots_per_partition": M,
        "total_shots": p * M, "threshold": threshold, "elapsed_seconds": elapsed,
        "modes": modes, "estimate": estimates, "analytic": exact, "bound": bound,
        "se": se, "actual_prime": actual_prime, "predicted_prime": predicted_prime,
        "rows": rows, "confusion": {"true_prime": tp, "false_prime": fp,
                                      "true_composite": tn, "false_composite": fn},
    }


def main() -> None:
    out = Path("results/low-shots")
    out.mkdir(parents=True, exist_ok=True)
    backend = AerSimulator(method="statevector")
    runs = {d: run(d, backend) for d in (4, 8, 16)}

    fig, axes = plt.subplots(3, 2, figsize=(13, 12), constrained_layout=True)
    for row, (d, r) in enumerate(runs.items()):
        ax = axes[row, 0]
        ax.plot(r["modes"], r["analytic"], "o-", color="black", ms=3, label=r"analytic $\alpha_n$")
        ax.errorbar(r["modes"], r["estimate"], yerr=2.576*r["se"], fmt=".", capsize=2,
                    label="low-shot estimate (99% marginal)")
        ax.plot(r["modes"], r["bound"], "--", color="tab:green", lw=1.8, label=r"$B_n$")
        wrong = r["actual_prime"] != r["predicted_prime"]
        if np.any(wrong):
            ax.scatter(r["modes"][wrong], r["estimate"][wrong], marker="x", s=80,
                       color="tab:red", label="misclassified")
        ax.set(title=f"d={d}: M={r['shots_per_partition']:,}, p={r['partitions']}",
               xlabel="n", ylabel=r"$\alpha_n$")
        ax.grid(alpha=.25); ax.legend(fontsize=8)

        ax = axes[row, 1]
        residual = r["estimate"] - r["analytic"]
        ax.axhline(0, color="black", lw=1)
        ax.errorbar(r["modes"], residual, yerr=2.576*r["se"], fmt=".", capsize=2)
        ax.axhline(r["threshold"], color="tab:red", ls="--", label=r"$+\Delta_d/2$")
        ax.axhline(-r["threshold"], color="tab:red", ls="--", label=r"$-\Delta_d/2$")
        c = r["confusion"]
        ax.set(title=f"TP={c['true_prime']}, TN={c['true_composite']}, FP={c['false_prime']}, FN={c['false_composite']}",
               xlabel="n", ylabel=r"$\widehat\alpha_n-\alpha_n$")
        ax.grid(alpha=.25); ax.legend(fontsize=8)
    fig.suptitle("Low-shot PIED validation against deterministic primality", fontsize=15)
    fig.savefig(out / "low-shot-validation.png", dpi=180)
    fig.savefig(out / "low-shot-validation.pdf")
    plt.close(fig)

    serial = {}
    for d, r in runs.items():
        serial[str(d)] = {k: v for k, v in r.items() if k not in {
            "modes", "estimate", "analytic", "bound", "se", "actual_prime", "predicted_prime"
        }}
    (out / "classification.json").write_text(json.dumps(serial, indent=2) + "\n")
    print(json.dumps(serial, indent=2))


if __name__ == "__main__":
    main()
