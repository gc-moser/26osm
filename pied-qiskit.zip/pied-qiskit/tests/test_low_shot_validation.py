"""Regression check for the recorded, seeded low-shot experiment."""

import json
from pathlib import Path


def test_recorded_low_shot_run_has_no_misclassifications():
    path = Path(__file__).parents[1] / "results" / "low-shots" / "classification.json"
    data = json.loads(path.read_text())
    expected = {
        "4": {"true_prime": 3, "false_prime": 0, "true_composite": 2, "false_composite": 0},
        "8": {"true_prime": 6, "false_prime": 0, "true_composite": 7, "false_composite": 0},
        "16": {"true_prime": 10, "false_prime": 0, "true_composite": 19, "false_composite": 0},
    }
    for d, counts in expected.items():
        assert data[d]["confusion"] == counts
        assert all(row["correct"] for row in data[d]["rows"])
