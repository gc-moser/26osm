"""Run the exact IBM Aer reproduction and emit machine-readable results."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from pied.core import (
    analytic_fourier_coefficient_uniform,
    analytic_purity,
    classify_modes,
    extract_fourier_modes,
    simulate_exact_purity,
    simulate_swap_probability,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dimension", "-d", type=int, default=4)
    parser.add_argument("--points", "-p", type=int, default=257)
    parser.add_argument("--omega", type=float, default=0.1)
    parser.add_argument("--output", type=Path, default=Path("results/reproduction.json"))
    args = parser.parse_args()

    times = np.linspace(0, np.pi / args.omega, args.points)
    analytic = np.asarray(analytic_purity(args.dimension, times, omega=args.omega))
    statevector = np.array([
        simulate_exact_purity(args.dimension, t, omega=args.omega) for t in times
    ])
    swap = np.array([
        2 * simulate_swap_probability(args.dimension, t, omega=args.omega) - 1 for t in times
    ])
    modes = np.arange(2, 2 * args.dimension - 1)
    extracted = extract_fourier_modes(times, swap, modes, omega=args.omega)
    expected = np.array([
        analytic_fourier_coefficient_uniform(args.dimension, int(n)) for n in modes
    ])
    report = {
        "dimension": args.dimension,
        "points": args.points,
        "omega": args.omega,
        "max_abs_error_statevector_vs_analytic": float(np.max(np.abs(statevector - analytic))),
        "max_abs_error_swap_vs_analytic": float(np.max(np.abs(swap - analytic))),
        "max_abs_error_fourier_vs_analytic": float(np.max(np.abs(extracted - expected))),
        "classification": {str(k): v for k, v in classify_modes(args.dimension, modes, expected).items()},
        "modes": modes.tolist(),
        "fourier_extracted": extracted.tolist(),
        "fourier_analytic": expected.tolist(),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()

