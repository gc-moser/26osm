"""Timed finite-shot IBM Aer runs with B_n and uncertainty plots."""

from __future__ import annotations

import json
import time
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from qiskit import transpile
from qiskit_aer import AerSimulator

from finite_shot_study import SEED, design, dct1_coefficients, is_prime
from pied.core import (
    analytic_fourier_coefficient_uniform,
    analytic_purity,
    build_swap_test_circuit,
    prime_bound_uniform,
)


def run_dimension(d: int, backend: AerSimulator) -> dict:
    spec = design(d)
    p, shots = spec["partitions"], spec["shots_per_partition"]
    x = np.linspace(0, np.pi, p)

    t0 = time.perf_counter()
    circuits = [build_swap_test_circuit(d, float(t), omega=1.0) for t in x]
    t1 = time.perf_counter()
    transpiled = transpile(circuits, backend, optimization_level=3, seed_transpiler=SEED)
    t2 = time.perf_counter()
    result = backend.run(transpiled, shots=shots, seed_simulator=SEED + d).result()
    t3 = time.perf_counter()

    zeros = np.array([result.get_counts(i).get("0", 0) for i in range(p)])
    sampled = 2 * zeros / shots - 1
    exact = np.asarray(analytic_purity(d, x))
    sampled_modes = dct1_coefficients(sampled)
    dct_exact_modes = dct1_coefficients(exact)
    modes = np.arange(2, 2 * (d - 1) + 1)
    formula_modes = np.array([analytic_fourier_coefficient_uniform(d, int(n)) for n in modes])
    bound = np.array([prime_bound_uniform(d, int(n)) for n in modes])

    N = p - 1
    endpoint = np.ones(p); endpoint[[0, -1]] = 0.5
    # Exact Bernoulli variance propagated through the DCT estimator.
    var_gamma = (1 - exact**2) / shots
    mode_se = np.array([
        np.sqrt(np.sum(((2 / N) * endpoint * np.cos(n * np.pi * np.arange(p) / N))**2 * var_gamma))
        for n in modes
    ])
    t4 = time.perf_counter()
    timing = {
        "circuit_construction_seconds": t1 - t0,
        "transpilation_seconds": t2 - t1,
        "aer_execution_seconds": t3 - t2,
        "analysis_seconds": t4 - t3,
        "total_seconds": t4 - t0,
    }
    return {
        "design": spec, "x": x, "exact": exact, "sampled": sampled,
        "modes": modes, "sampled_modes": sampled_modes[modes],
        "dct_exact_modes": dct_exact_modes[modes], "formula_modes": formula_modes,
        "bound": bound, "mode_se": mode_se, "timing": timing,
        "max_floating_dct_error": float(np.max(np.abs(dct_exact_modes[modes] - formula_modes))),
        "max_finite_shot_error": float(np.max(np.abs(sampled_modes[modes] - formula_modes))),
    }


def main() -> None:
    out = Path("results/finite-shots-aer")
    out.mkdir(parents=True, exist_ok=True)
    backend = AerSimulator(method="statevector")
    runs = {d: run_dimension(d, backend) for d in (4, 8, 16)}

    fig, axes = plt.subplots(3, 3, figsize=(16, 12), constrained_layout=True)
    for row, (d, run) in enumerate(runs.items()):
        spec = run["design"]
        ax = axes[row, 0]
        ax.plot(run["x"] / np.pi, run["exact"], color="black", lw=1.3, label="analytic")
        ax.scatter(run["x"] / np.pi, run["sampled"], s=8, alpha=.65, label="Aer finite shots")
        ax.set(title=f"d={d}: purity; p={spec['partitions']}, M={spec['shots_per_partition']:,}",
               xlabel=r"$\omega t/\pi$", ylabel=r"$\mathrm{Tr}(\rho_A^2)$")
        ax.grid(alpha=.25); ax.legend(fontsize=8)

        ax = axes[row, 1]
        ax.plot(run["modes"], run["formula_modes"], "o-", color="black", ms=3, label=r"analytic $\alpha_n$")
        ax.errorbar(run["modes"], run["sampled_modes"], yerr=2.576 * run["mode_se"], fmt=".",
                    capsize=2, color="tab:blue", label="Aer estimate (99% marginal)")
        ax.plot(run["modes"], run["bound"], "--", lw=1.8, color="tab:green", label="lower bound $B_n$")
        primes = np.array([i for i, n in enumerate(run["modes"]) if is_prime(int(n))])
        ax.scatter(run["modes"][primes], run["sampled_modes"][primes], facecolors="none",
                   edgecolors="tab:red", s=55, label="prime")
        ax.set(title=f"d={d}: Fourier decision", xlabel="mode n", ylabel=r"$\alpha_n$")
        ax.grid(alpha=.25); ax.legend(fontsize=8)

        ax = axes[row, 2]
        residual = run["sampled_modes"] - run["formula_modes"]
        ax.axhline(0, color="black", lw=1)
        ax.errorbar(run["modes"], residual, yerr=2.576 * run["mode_se"], fmt=".", capsize=2)
        ax.axhline(spec["minimum_gap"] / 2, color="tab:red", ls="--", label=r"$+\Delta_d/2$")
        ax.axhline(-spec["minimum_gap"] / 2, color="tab:red", ls="--", label=r"$-\Delta_d/2$")
        ax.set(title=f"d={d}: numerical error", xlabel="mode n", ylabel=r"$\widehat\alpha_n-\alpha_n$")
        ax.grid(alpha=.25); ax.legend(fontsize=8)
    fig.suptitle("Timed finite-shot PIED runs on IBM Qiskit Aer", fontsize=15)
    fig.savefig(out / "finite-shot-aer-with-Bn.png", dpi=180)
    fig.savefig(out / "finite-shot-aer-with-Bn.pdf")
    plt.close(fig)

    serialisable = {}
    for d, r in runs.items():
        serialisable[str(d)] = {
            **r["design"], **r["timing"],
            "max_floating_dct_error": r["max_floating_dct_error"],
            "max_finite_shot_error": r["max_finite_shot_error"],
        }
    (out / "timings-and-errors.json").write_text(json.dumps(serialisable, indent=2) + "\n")
    print(json.dumps(serialisable, indent=2))


if __name__ == "__main__":
    main()
