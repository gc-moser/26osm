"""Compare the faithful notebook transcription with the optimised circuit."""

from __future__ import annotations

import json
from pathlib import Path

from qiskit import transpile
from qiskit_aer import AerSimulator

from pied.core import build_evolution_circuit, build_swap_test_circuit
from pied.reference import build_reference_evolution, build_reference_swap_test


def metrics(circuit):
    return {
        "qubits": circuit.num_qubits,
        "depth": circuit.depth(),
        "size": circuit.size(),
        "operations": dict(circuit.count_ops()),
    }


def main() -> None:
    backend = AerSimulator()
    comparison = {}
    for d in (4, 8, 16):
        reference = build_reference_evolution(d, 0.731)
        optimised = build_evolution_circuit(d, 0.731)
        reference_swap = build_reference_swap_test(d, 0.731)
        optimised_swap = build_swap_test_circuit(d, 0.731)
        comparison[str(d)] = {
            "one_copy_logical": {
                "reference": metrics(reference),
                "optimised": metrics(optimised),
            },
            "swap_test_transpiled_level_3": {
                "reference": metrics(transpile(reference_swap, backend, optimization_level=3)),
                "optimised": metrics(transpile(optimised_swap, backend, optimization_level=3)),
            },
        }
    out = Path("results/reference-comparison.json")
    out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(comparison, indent=2) + "\n")
    print(json.dumps(comparison, indent=2))


if __name__ == "__main__":
    main()

