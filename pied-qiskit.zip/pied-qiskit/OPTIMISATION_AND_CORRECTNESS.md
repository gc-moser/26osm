# Optimisation and correctness of the PIED circuit

## 1. Hamiltonian reduction

For the number basis used by Southier et al., let
`N_A|j>=j|j>` and `N_B|k>=k|k>`.  Their Hamiltonian has the form

```text
H = H_A tensor I + I tensor H_B + lambda H_A tensor H_B.
```

All three summands commute.  Hence its propagator factors into two local
unitaries and one interaction.  Local unitaries cannot change the spectrum of
either reduced density matrix, and therefore cannot change
`Tr(rho_A^2)`.  For PIED it is sufficient to implement

```text
U(theta) = exp(-i theta N_A tensor N_B),  theta=omega*t.
```

This omission is exact for the measured quantity, not a Trotter approximation.

## 2. Binary controlled-phase synthesis

Let `d=2^r` and encode number states in binary:

```text
j = sum_(a=0)^(r-1) 2^a j_a,
k = sum_(b=0)^(r-1) 2^b k_b.
```

Then

```text
j k = sum_(a,b) 2^(a+b) j_a k_b.
```

A controlled-phase gate `CP(phi)` on bits `(j_a,k_b)` multiplies a basis state
by `exp(i phi j_a k_b)`.  Therefore the product

```text
V(theta) = product_(a,b) CP(-theta 2^(a+b))
```

acts on every computational basis state as

```text
V(theta)|j,k>
 = product_(a,b) exp[-i theta 2^(a+b)j_a k_b]|j,k>
 = exp[-i theta j k]|j,k>
 = U(theta)|j,k>.
```

Since computational basis states form a basis, `V(theta)=U(theta)` as
operators.  This proves exact correctness of the optimised evolution circuit.
It uses exactly `r^2=(log2 d)^2` two-qubit controlled phases per evolved copy.

## 3. Relation to the Walsh reference circuit

The published Qiskit implementation expands the diagonal phase function in a
Walsh basis.  Its parity ladders compute Walsh characters, apply `RZ` angles,
and uncompute the parities.  The bilinear part represents the same phase
`-theta*j*k`; its remaining one-register terms are local phases arising from
the chosen Walsh representation and index centring.  By Section 1 those local
terms leave the reduced purity invariant.

The automated equivalence test constructs both circuits for `d=4,8`, traces
out subsystem B, and checks their purities at several times to below `2e-12`.
The analytic proof above holds for every power-of-two `d` and every real time.

## 4. SWAP-test correctness

Let the two evolved copies be in `rho_AB tensor rho_A'B'`.  Conditional SWAP
acts only on A and A'.  The standard identity

```text
Tr[S_AA' (rho_A tensor rho_A)] = Tr(rho_A^2)
```

implies

```text
P(ancilla=0) = (1 + Tr(rho_A^2))/2.
```

Thus `2P(0)-1` is exactly the reduced purity used in PIED.  The test suite
checks this identity with IBM Qiskit Aer against the analytic finite sum.

## 5. Optimal time grid

For a finite `d`-level system, differences `j-k` and `l-m` lie between
`-(d-1)` and `d-1`.  The purity is consequently a cosine polynomial of degree

```text
N = (d-1)^2.
```

The DCT-I grid `x_k=k*pi/N`, `k=0,...,N`, has `N+1` points.  Discrete cosine
orthogonality recovers every coefficient of any degree-N cosine polynomial
exactly.  Fewer than `N+1` scalar samples cannot identify all `N+1`
coefficients without additional assumptions.  Hence the chosen partition
counts are information-theoretically minimal for alias-free recovery of the
complete PIED trace:

| d | highest mode N | partitions N+1 |
|---:|---:|---:|
| 4 | 9 | 10 |
| 8 | 49 | 50 |
| 16 | 225 | 226 |

## 6. Shot calculation

At time point k, one SWAP-test shot is a random variable `X in {-1,+1}` with
mean equal to the purity.  Let `b_k` be the endpoint-weighted DCT coefficient:
`b_0=b_N=1/N` and `b_k=2/N` otherwise (with an additional cosine factor of
absolute value at most one).  If M shots are used at every time, Hoeffding's
inequality gives, for one Fourier mode,

```text
P(|alpha_hat-alpha| >= eta)
 <= 2 exp[-M eta^2/(2 sum_k b_k^2)].
```

Let `Delta_d` be the smallest analytic separation between the prime locus and
any composite coefficient in the tested interval `2 <= n <= 2(d-1)`.  Taking
`eta=Delta_d/2` and applying a union bound to all `K=2d-3` tested modes yields

```text
M >= 2(sum_k b_k^2) log(2K/epsilon)/(Delta_d/2)^2.
```

For simultaneous failure probability `epsilon=0.01`, rounding upward gives:

| d | minimum gap Delta_d | shots per partition |
|---:|---:|---:|
| 4 | 0.0625000 | 5,939 |
| 8 | 0.0117188 | 37,012 |
| 16 | 0.00512695 | 46,783 |

These are conservative sufficient values under a clearly stated 99% joint
confidence criterion.  They are “optimal” only relative to this criterion:
the partition count is minimal, while the shot count is the smallest integer
satisfying the displayed Hoeffding/union-bound certificate.  Empirical or
variance-aware allocation can use fewer shots, but loses this simple rigorous
guarantee.

## 7. What the optimisation does not solve

The optimisation reduces circuit depth and removes Fourier oversampling.  It
does not remove the PIED resource bottleneck: the useful interval grows only
linearly with d, while a qubit encoding has `d=2^r`; statevector simulation of
the two-copy SWAP test and physical precision requirements remain substantial.
It is therefore a correct circuit optimisation, not a proof that PIED is an
efficient primality algorithm in the input bit length.

## 8. Exponential lower bound in the bit length

Let the tested integer be `n` and let `b=ceil(log2(n+1))` be its input length.
The guaranteed PIED decision interval is `n <= 2(d-1)`.  Therefore any run
covering n must satisfy

```text
d >= n/2 + 1 = Omega(2^b).
```

This immediately gives two lower bounds for the present full-spectrum method.

First, the purity is a cosine polynomial of degree `(d-1)^2`.  Alias-free
recovery of an otherwise unrestricted polynomial in this space needs at least
`(d-1)^2+1` scalar samples.  Hence

```text
p = Omega(d^2) = Omega(n^2) = Omega(4^b).
```

Even with one shot per partition, the number of circuit executions is already
exponential in b.

Second, finite precision makes the lower bound stronger.  Consider the last
mode in the guaranteed interval, `n_d=2(d-1)`.  It is composite and its prime
bound is zero.  The admissible divisor pairs `(2,d-1)` and `(d-1,2)` give

```text
alpha_(n_d)
 = (4/d^4)[(d-2)(d-(d-1))+(d-(d-1))(d-2)]
 = 8(d-2)/d^4
 = Theta(d^-3).
```

Thus the worst-case decision gap is at most `Theta(d^-3)`.  Estimating the
mean of a bounded Bernoulli-derived observable to additive error proportional
to this gap with constant success probability requires
`Omega(Delta^-2)=Omega(d^6)` independent samples.  This follows, for example,
from the two-point testing lower bound for Bernoulli means (equivalently from
the `1/sqrt(S)` standard-error law or the Cramer--Rao bound away from
deterministic probabilities).  Consequently the total shot count S obeys

```text
S = Omega(d^6) = Omega(n^6) = Omega(2^(6b)).
```

This is a lower bound for the Fourier-estimation PIED decision procedure, not
for primality testing in general.  It also does not assert that every n has
this difficulty; it is a worst-case bound required of a method that covers the
whole stated interval.  The controlled-phase optimisation reduces the gate
count of one shot to `Theta((log d)^2)=Theta(b^2)`, but multiplying by the
required shots still leaves at least `Omega(2^(6b)b^2)` elementary controlled
operations in the certified worst case.
