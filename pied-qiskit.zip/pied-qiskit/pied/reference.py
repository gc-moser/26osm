"""Faithful transcription of the public Walsh/Qiskit reference notebook.

Source: santosvictorf/primes-identification-using-qcomputers,
``qiskit-simulations/qiskit-simulation.ipynb``.  This is kept separate from
the optimised implementation so the comparison is executable and auditable.
"""

from __future__ import annotations

from math import log2

import numpy as np
from qiskit import QuantumCircuit


def walsh_data(d: int) -> tuple[np.ndarray, np.ndarray]:
    if d < 2 or d & (d - 1):
        raise ValueError("d must be a power of two")
    q = 2 * int(log2(d))
    num_angles = q * q // 4 + q
    angles = np.zeros(num_angles, dtype=float)
    indices = np.zeros(num_angles, dtype=int)
    result_h1 = -(8 ** (q / 2)) * (1 + 2 ** (q / 2)) / 8
    result_h2 = (4**q) / 16
    for j1 in range(q // 2):
        base = j1 + (j1 + 1) * (q // 2)
        angles[j1] = result_h1 / 2**j1
        angles[base] = angles[j1]
        indices[j1] = 2**j1
        indices[base] = 2 ** (j1 + q // 2)
        for j2 in range(q // 2):
            pos = base + j2 + 1
            angles[pos] = result_h2 / 2 ** (j1 + j2)
            indices[pos] = indices[base] + 2**j2
    return angles, indices


def append_reference_walsh(qc: QuantumCircuit, offset: int, d: int, theta: float) -> None:
    q = 2 * int(log2(d))
    angles, indices = walsh_data(d)
    for coefficient, index in zip(angles, indices):
        bits = format(index, f"0{q}b")[::-1]
        target = bits.rfind("1")
        controls = [i for i, bit in enumerate(bits) if bit == "1" and i != target]
        for i in controls:
            qc.cx(offset + i, offset + target)
        qc.rz(2 * coefficient * theta / 2**q, offset + target)
        for i in reversed(controls):
            qc.cx(offset + i, offset + target)


def build_reference_evolution(d: int, t: float, *, omega: float = 1.0) -> QuantumCircuit:
    """One-copy circuit exactly following the notebook's Walsh synthesis."""
    q = 2 * int(log2(d))
    qc = QuantumCircuit(q, name="reference Walsh PIED")
    qc.h(range(q))
    append_reference_walsh(qc, 0, d, omega * t)
    return qc


def build_reference_swap_test(d: int, t: float, *, omega: float = 1.0) -> QuantumCircuit:
    q = 2 * int(log2(d))
    qc = QuantumCircuit(2 * q + 1, 1)
    qc.h(range(1, 2 * q + 1))
    append_reference_walsh(qc, 1, d, omega * t)
    append_reference_walsh(qc, 1 + q, d, omega * t)
    qc.h(0)
    for i in range(1, q // 2 + 1):
        qc.cswap(0, i, i + q)
    qc.h(0)
    qc.measure(0, 0)
    return qc

