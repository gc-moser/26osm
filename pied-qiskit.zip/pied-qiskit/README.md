# PIED in Qiskit

This repository implements prime identification via entanglement dynamics
(PIED), validates it against the analytic formulae, transcribes the public
reference circuit, and supplies a more efficient circuit synthesis.

## Scope and provenance

Southier, Santos, Souto Ribeiro and Ribeiro introduced the physical principle
for two cross-Kerr-coupled oscillators and two interacting spins in
*Physical Review A* **108**, 042404 (2023),
<https://doi.org/10.1103/PhysRevA.108.042404>.  That paper does **not** contain a
Qiskit listing.  The qubit algorithm and its Qiskit/Walsh implementation were
developed later by dos Santos and Maziero, *Physical Review A* **110**, 022405
(2024), <https://doi.org/10.1103/PhysRevA.110.022405>, and released publicly in
the authors' repository:
<https://github.com/santosvictorf/primes-identification-using-qcomputers>.

Accordingly, this project provides:

1. the Southier dynamics for uniform, spin-coherent, and truncated
   oscillator-coherent product states;
2. a faithful, executable transcription of the later public Qiskit reference
   (`pied/reference.py`);
3. an optimised binary synthesis (`pied/core.py`);
4. exact IBM Qiskit Aer reproduction tests.

## Mathematical implementation

For each subsystem, a `d=2^r` level state is encoded in `r` qubits.  Ignoring
local rotations, which do not change bipartite entanglement, the evolution is

```text
U(t)|j,k> = exp(-i omega t j k)|j,k>.
```

Writing `j=sum_i 2^i j_i` and `k=sum_l 2^l k_l` gives

```text
U(t) = product_(i,l) CP(-omega t 2^(i+l))_(j_i,k_l).
```

Thus the optimised evolution is exact and uses `r^2=(log2 d)^2`
controlled-phase gates per copy.  The SWAP test uses two evolved copies and
swaps only the `A` registers; its ancilla probability obeys

```text
p(0) = (1 + Tr(rho_A^2))/2.
```

The code also evaluates the analytic finite sum

```text
Tr(rho_A^2) = sum_(j,k) p_j p_k
              |sum_l p_l exp[-i omega t (j-k)l]|^2,
```

where `p_j` is the initial number-basis probability.  This single expression
covers all three supplied initial states.

## Installation and execution

```bash
python -m venv .venv
. .venv/bin/activate
pip install -e '.[test]'
pytest -q
python run_reproduction.py --dimension 4 --points 257 --omega 0.1
python compare_reference.py
```

The pinned reference environment uses Qiskit 2.1.0 and Qiskit Aer 0.17.x.

## Exact IBM simulator reproduction

`run_reproduction.py` performs three independent comparisons:

- Qiskit `Statevector` plus partial trace versus the analytic purity;
- IBM Qiskit Aer `AerSimulator(method="statevector")` SWAP-test probability
  versus the same analytic purity;
- numerical cosine transform versus the analytic Fourier coefficients.

For `d=4`, 257 half-period samples, and `omega=0.1`, the recorded maximum
absolute errors are:

| Check | Maximum absolute error |
|---|---:|
| Statevector purity vs analytic | `1.33e-15` |
| Aer SWAP test vs analytic | `4.22e-15` |
| Extracted vs analytic Fourier modes | `4.44e-16` |

The recovered classification is exactly
`2,3,5 = prime` and `4,6 = composite`.

“Exactly” here means equality up to IEEE-754 rounding.  The Aer run saves the
ancilla probability directly and therefore introduces no Monte Carlo error.
A finite-shot run cannot reproduce an irrational or general real-valued
analytic probability exactly; its error is statistical by construction.

## Comparison with the public reference code

The reference notebook uses a Walsh expansion.  `pied/reference.py` preserves
its angle/index construction and parity ladders.  The test suite establishes
that its reduced purity equals the optimised implementation at several times
for `d=4` and `d=8` to below `2e-12`.

Logical one-copy metrics are:

| d | Reference size/depth | Optimised size/depth | Reference entangling gates | Optimised entangling gates |
|---:|---:|---:|---:|---:|
| 4 | 20 / 11 | 8 / 4 | 8 CX | 4 CP |
| 8 | 39 / 17 | 15 / 6 | 18 CX | 9 CP |
| 16 | 64 / 23 | 24 / 8 | 32 CX | 16 CP |

The optimisation follows from recognising the Hamiltonian as the product of
two binary integers.  It removes the Walsh single-register terms and parity
compute/uncompute ladders; those terms implement local phases or an indirect
representation of the same bilinear phase.  Local phases do not affect the
purity measured by PIED.

The public notebook also runs each time separately with finite shots.  This
project separates concerns:

- exact statevector/Aer probability for correctness;
- SWAP-test circuit construction for shot-based or hardware experiments;
- vectorised analytic purity and Simpson integration for analysis;
- reusable circuit functions rather than notebook-global variables.

## Files

- `pied/core.py`: optimised circuits, coherent states, analytic formulae,
  Fourier extraction and classification.
- `pied/reference.py`: faithful Walsh reference transcription.
- `run_reproduction.py`: exact Aer reproduction.
- `compare_reference.py`: gate/depth comparison.
- `finite_shot_study.py`: certified finite-shot design and plots for
  `d=4,8,16`.
- `finite_shot_aer_study.py`: actual timed IBM Aer finite-shot circuits,
  uncertainty propagation, residuals, and the decision bound `B_n`.
- `low_shot_validation.py`: reduced-shot experiment (`M=3000,5000,10000`),
  independent deterministic ground truth, and false-positive/false-negative
  reporting.
- `OPTIMISATION_AND_CORRECTNESS.md`: formal proof and resource derivation.
- `tests/test_pied.py`: regression and equivalence tests.
- `results/reproduction-d4.json`: recorded exact validation.
- `results/reference-comparison.json`: recorded circuit metrics.

## Limitations

- The useful prime-identification interval of the uniform finite-dimensional
  construction is `2 <= n <= 2(d-1)`; increasing `n` therefore still requires
  increasing `d`.
- Exact state preparation for arbitrary coherent amplitudes is not claimed to
  be efficient.  Uniform input uses only Hadamards.
- Simulator equality validates the implementation, not scalability or quantum
  advantage.
- Transpiled hardware gate counts depend on the backend target.  The logical
  comparison above is backend-independent; the JSON also records Aer
  optimisation-level-3 metrics.

## Verification sources

- A. L. M. Southier *et al.*, “Identifying primes from entanglement dynamics,”
  *Phys. Rev. A* **108**, 042404 (2023),
  <https://doi.org/10.1103/PhysRevA.108.042404>.
- V. F. dos Santos and J. Maziero, “Using quantum computers to identify prime
  numbers via entanglement dynamics,” *Phys. Rev. A* **110**, 022405 (2024),
  <https://doi.org/10.1103/PhysRevA.110.022405>.
- Public author implementation,
  <https://github.com/santosvictorf/primes-identification-using-qcomputers>.
- Qiskit Aer documentation, <https://qiskit.github.io/qiskit-aer/> and its
  saved-probability instruction reference,
  <https://qiskit.github.io/qiskit-aer/apidocs/aer_library.html>.
