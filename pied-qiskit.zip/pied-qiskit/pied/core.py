"""Prime identification via entanglement dynamics (PIED).

The physical interaction is

    U(theta)|j,k> = exp(-i theta j k)|j,k>,  theta = omega*t.

For power-of-two local dimension d, j and k are binary encoded.  The
interaction is then exactly a product of log2(d)^2 controlled-phase gates.
This avoids constructing a dense  d^2 x d^2 diagonal unitary.

The module supports the uniform state used by the public Qiskit reference
implementation, and the oscillator/spin coherent states of Southier et al.
The latter are encoded in a finite power-of-two register (with explicit
truncation in the oscillator case).
"""

from __future__ import annotations

from dataclasses import dataclass
from math import comb, factorial, log2
from typing import Literal, Sequence

import numpy as np
from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister
from qiskit.quantum_info import Statevector, partial_trace, purity
from qiskit_aer import AerSimulator
from scipy.integrate import simpson

InitialState = Literal["uniform", "spin_coherent", "oscillator_coherent"]


@dataclass(frozen=True)
class PIEDResult:
    times: np.ndarray
    purities: np.ndarray
    modes: np.ndarray
    coefficients: np.ndarray


def _validate_dimension(d: int) -> int:
    if d < 2 or d & (d - 1):
        raise ValueError("d must be a power of two and at least 2")
    return int(log2(d))


def subsystem_amplitudes(
    d: int,
    kind: InitialState = "uniform",
    *,
    u: float = 1.0,
    alpha: complex | None = None,
) -> np.ndarray:
    """Return one normalised d-level subsystem state.

    For ``spin_coherent``, d=2S+1 and the coefficients are those of Eq. (12)
    of Southier et al., with |s|^2=u and a real nonnegative s.
    For ``oscillator_coherent``, the coherent state is truncated at d levels
    and renormalised; alpha defaults to sqrt(u/2), matching Eq. (4).
    """
    _validate_dimension(d)
    if u < 0:
        raise ValueError("u must be nonnegative")
    if kind == "uniform":
        return np.full(d, 1 / np.sqrt(d), dtype=complex)
    if kind == "spin_coherent":
        n = np.arange(d)
        amps = np.sqrt([comb(d - 1, int(x)) for x in n]) * u ** (n / 2)
        amps = amps / (1 + u) ** ((d - 1) / 2)
        return np.asarray(amps, dtype=complex)
    if kind == "oscillator_coherent":
        a = np.sqrt(u / 2) if alpha is None else alpha
        amps = np.array([a**n / np.sqrt(factorial(n)) for n in range(d)], dtype=complex)
        amps *= np.exp(-abs(a) ** 2 / 2)
        return amps / np.linalg.norm(amps)
    raise ValueError(f"unknown initial state: {kind}")


def _prepare_subsystem(qc: QuantumCircuit, qubits: Sequence, amps: np.ndarray, kind: InitialState) -> None:
    if kind == "uniform":
        qc.h(qubits)
    else:
        qc.prepare_state(amps, qubits)


def append_cross_kerr(
    qc: QuantumCircuit,
    a: Sequence,
    b: Sequence,
    theta: float,
) -> None:
    """Append the exact binary synthesis of exp(-i theta n_A n_B)."""
    for i, qa in enumerate(a):
        for j, qb in enumerate(b):
            qc.cp(-theta * (2 ** (i + j)), qa, qb)


def build_evolution_circuit(
    d: int,
    t: float,
    *,
    omega: float = 1.0,
    initial_state: InitialState = "uniform",
    u: float = 1.0,
    alpha: complex | None = None,
) -> QuantumCircuit:
    """Build one d x d PIED system without measurement."""
    r = _validate_dimension(d)
    a = QuantumRegister(r, "A")
    b = QuantumRegister(r, "B")
    qc = QuantumCircuit(a, b, name="PIED evolution")
    amps = subsystem_amplitudes(d, initial_state, u=u, alpha=alpha)
    _prepare_subsystem(qc, a, amps, initial_state)
    _prepare_subsystem(qc, b, amps, initial_state)
    append_cross_kerr(qc, a, b, omega * t)
    return qc


def build_swap_test_circuit(
    d: int,
    t: float,
    *,
    omega: float = 1.0,
    initial_state: InitialState = "uniform",
    u: float = 1.0,
    alpha: complex | None = None,
    measure: bool = True,
) -> QuantumCircuit:
    """Build the two-copy SWAP test measuring Tr(rho_A^2).

    Qubit layout is ancilla, A, B, A', B'.  Only A and A' are swapped.
    Hence p(ancilla=0)=(1+Tr(rho_A^2))/2.
    """
    r = _validate_dimension(d)
    anc = QuantumRegister(1, "anc")
    a = QuantumRegister(r, "A")
    b = QuantumRegister(r, "B")
    ap = QuantumRegister(r, "Ap")
    bp = QuantumRegister(r, "Bp")
    if measure:
        c = ClassicalRegister(1, "c")
        qc = QuantumCircuit(anc, a, b, ap, bp, c)
    else:
        qc = QuantumCircuit(anc, a, b, ap, bp)
    amps = subsystem_amplitudes(d, initial_state, u=u, alpha=alpha)
    for reg in (a, b, ap, bp):
        _prepare_subsystem(qc, reg, amps, initial_state)
    append_cross_kerr(qc, a, b, omega * t)
    append_cross_kerr(qc, ap, bp, omega * t)
    qc.h(anc)
    for qa, qb in zip(a, ap):
        qc.cswap(anc[0], qa, qb)
    qc.h(anc)
    if measure:
        qc.measure(anc[0], c[0])
    return qc


def simulate_exact_purity(
    d: int,
    t: float,
    *,
    omega: float = 1.0,
    initial_state: InitialState = "uniform",
    u: float = 1.0,
    alpha: complex | None = None,
) -> float:
    """Exact statevector purity of A; no sampling error."""
    qc = build_evolution_circuit(
        d, t, omega=omega, initial_state=initial_state, u=u, alpha=alpha
    )
    sv = Statevector.from_instruction(qc)
    r = _validate_dimension(d)
    rho_a = partial_trace(sv, list(range(r, 2 * r)))
    return float(np.real_if_close(purity(rho_a)))


def simulate_swap_probability(
    d: int,
    t: float,
    *,
    omega: float = 1.0,
    initial_state: InitialState = "uniform",
    u: float = 1.0,
    alpha: complex | None = None,
) -> float:
    """Exact IBM Aer probability p(ancilla=0), without finite shots."""
    qc = build_swap_test_circuit(
        d, t, omega=omega, initial_state=initial_state, u=u, alpha=alpha, measure=False
    )
    qc.save_probabilities([0], label="p_ancilla")
    result = AerSimulator(method="statevector").run(qc).result()
    return float(result.data(0)["p_ancilla"][0])


def analytic_purity(
    d: int,
    t: float | np.ndarray,
    *,
    omega: float = 1.0,
    initial_state: InitialState = "uniform",
    u: float = 1.0,
    alpha: complex | None = None,
) -> float | np.ndarray:
    """Analytic finite-sum purity for any supported product input state.

    If subsystem probabilities are p_j, the expression is
      sum_{j,k,l,m} p_j p_k p_l p_m exp[-i theta (j-k)(l-m)].
    It is evaluated as sum_{j,k} p_j p_k |sum_l p_l exp[-i theta(j-k)l]|^2.
    """
    p = np.abs(subsystem_amplitudes(d, initial_state, u=u, alpha=alpha)) ** 2
    tt = np.atleast_1d(np.asarray(t, dtype=float))
    delta = np.arange(d)[:, None] - np.arange(d)[None, :]
    pair_weight = p[:, None] * p[None, :]
    levels = np.arange(d)
    out = np.empty(tt.size)
    for z, time in enumerate(tt):
        characteristic = np.exp(-1j * omega * time * delta[..., None] * levels) @ p
        out[z] = np.sum(pair_weight * np.abs(characteristic) ** 2).real
    return float(out[0]) if np.ndim(t) == 0 else out


def divisors(n: int) -> list[int]:
    result: set[int] = set()
    for x in range(1, int(np.sqrt(n)) + 1):
        if n % x == 0:
            result.update((x, n // x))
    return sorted(result)


def analytic_fourier_coefficient_uniform(d: int, n: int) -> float:
    """Uniform-state coefficient alpha_n from the qubit reference paper."""
    _validate_dimension(d)
    if n < 1 or n > (d - 1) ** 2:
        return 0.0
    valid = [x for x in divisors(n) if x < d and n // x < d]
    return 4.0 / d**4 * sum((d - x) * (d - n // x) for x in valid)


def prime_bound_uniform(d: int, n: int) -> float:
    if 1 < n < d:
        return 8.0 * (d - 1) * (d - n) / d**4
    if d <= n <= 2 * (d - 1):
        return 0.0
    raise ValueError("the prime-identification interval is 2 <= n <= 2(d-1)")


def extract_fourier_modes(
    times: Sequence[float],
    purities: Sequence[float],
    modes: Sequence[int],
    *,
    omega: float = 1.0,
) -> np.ndarray:
    """Extract cosine amplitudes over the half period [0, pi/omega]."""
    times = np.asarray(times, dtype=float)
    purities = np.asarray(purities, dtype=float)
    if times.shape != purities.shape:
        raise ValueError("times and purities must have the same shape")
    return np.array([
        simpson((2 * omega / np.pi) * purities * np.cos(n * omega * times), x=times)
        for n in modes
    ])


def classify_modes(d: int, modes: Sequence[int], coefficients: Sequence[float], *, atol: float = 1e-8) -> dict[int, bool]:
    """Classify in the provable interval; True means prime."""
    answer: dict[int, bool] = {}
    for n, c in zip(modes, coefficients):
        bound = prime_bound_uniform(d, int(n))
        answer[int(n)] = bool(np.isclose(c, bound, atol=atol, rtol=0.0))
    return answer

