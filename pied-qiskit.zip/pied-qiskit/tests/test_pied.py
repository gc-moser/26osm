import numpy as np
from qiskit import transpile
from qiskit_aer import AerSimulator

from pied.core import (
    analytic_fourier_coefficient_uniform,
    analytic_purity,
    build_evolution_circuit,
    classify_modes,
    extract_fourier_modes,
    simulate_exact_purity,
    simulate_swap_probability,
)
from pied.reference import build_reference_evolution


def test_evolution_matches_analytic_for_all_initial_states():
    for state in ("uniform", "spin_coherent", "oscillator_coherent"):
        for t in np.linspace(0, np.pi, 9):
            expected = analytic_purity(4, t, initial_state=state, u=0.7)
            actual = simulate_exact_purity(4, t, initial_state=state, u=0.7)
            assert abs(actual - expected) < 2e-12


def test_ibm_aer_swap_test_is_exact():
    for t in np.linspace(0, np.pi, 13):
        expected = analytic_purity(4, t)
        measured = 2 * simulate_swap_probability(4, t) - 1
        assert abs(measured - expected) < 2e-12


def test_fourier_coefficients_and_prime_classification():
    d = 4
    times = np.linspace(0, np.pi, 513)
    trace = analytic_purity(d, times)
    modes = np.arange(2, 2 * d - 1)
    extracted = extract_fourier_modes(times, trace, modes)
    expected = np.array([analytic_fourier_coefficient_uniform(d, int(n)) for n in modes])
    assert np.max(np.abs(extracted - expected)) < 2e-12
    assert classify_modes(d, modes, expected) == {2: True, 3: True, 4: False, 5: True, 6: False}


def test_optimised_evolution_gate_count():
    qc = build_evolution_circuit(16, 0.31)
    assert qc.count_ops().get("cp", 0) == 16
    tqc = transpile(qc, AerSimulator(), optimization_level=3)
    assert tqc.depth() > 0


def test_reference_walsh_and_optimised_have_same_purity():
    from qiskit.quantum_info import Statevector, partial_trace, purity

    for d in (4, 8):
        r = int(np.log2(d))
        for t in (0.0, 0.37, 1.11):
            sv = Statevector.from_instruction(build_reference_evolution(d, t))
            reference_purity = float(np.real(purity(partial_trace(sv, list(range(r, 2 * r))))))
            assert abs(reference_purity - simulate_exact_purity(d, t)) < 2e-12
