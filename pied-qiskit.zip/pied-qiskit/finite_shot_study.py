"""Finite-shot PIED study with analytically selected partitions and shots."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np

from pied.core import analytic_fourier_coefficient_uniform, analytic_purity, prime_bound_uniform


FAILURE_PROBABILITY = 0.01
SEED = 20260919


def is_prime(n: int) -> bool:
    return n >= 2 and all(n % k for k in range(2, int(np.sqrt(n)) + 1))


def design(d: int, epsilon: float = FAILURE_PROBABILITY) -> dict:
    """Return the minimum DCT-I grid and a conservative sufficient shot count.

    The purity is band-limited to N=(d-1)^2.  N+1 endpoints on [0,pi]
    therefore recover every cosine coefficient without aliasing.  Hoeffding's
    inequality and a union bound over K=2d-3 tested modes choose the shots.
    """
    nmax = (d - 1) ** 2
    partitions = nmax + 1
    tested = list(range(2, 2 * (d - 1) + 1))
    gaps = [
        analytic_fourier_coefficient_uniform(d, n) - prime_bound_uniform(d, n)
        for n in tested
        if not is_prime(n)
    ]
    delta = min(gaps)
    weights = np.full(partitions, 2 / (partitions - 1), dtype=float)
    weights[[0, -1]] = 1 / (partitions - 1)
    # |cos|<=1 yields a mode-independent rigorous upper bound.
    shots = int(np.ceil(2 * np.sum(weights**2) * np.log(2 * len(tested) / epsilon) / (delta / 2) ** 2))
    return {
        "dimension": d,
        "maximum_mode": nmax,
        "partitions": partitions,
        "tested_modes": len(tested),
        "minimum_gap": delta,
        "shots_per_partition": shots,
        "failure_probability_bound": epsilon,
        "total_shots": partitions * shots,
    }


def dct1_coefficients(values: np.ndarray) -> np.ndarray:
    """Cosine coefficients from an endpoint grid x_k=k*pi/N."""
    N = len(values) - 1
    k = np.arange(N + 1)
    endpoint = np.ones(N + 1)
    endpoint[[0, -1]] = 0.5
    return np.array([
        2 / N * np.sum(endpoint * values * np.cos(n * np.pi * k / N))
        for n in range(N + 1)
    ])


def simulate(d: int, rng: np.random.Generator) -> dict:
    spec = design(d)
    p = spec["partitions"]
    shots = spec["shots_per_partition"]
    x = np.linspace(0, np.pi, p)
    exact = np.asarray(analytic_purity(d, x))
    p0 = (1 + exact) / 2
    zeros = rng.binomial(shots, p0)
    sampled = 2 * zeros / shots - 1
    exact_modes = dct1_coefficients(exact)
    sampled_modes = dct1_coefficients(sampled)
    return {"design": spec, "x": x, "exact": exact, "sampled": sampled,
            "exact_modes": exact_modes, "sampled_modes": sampled_modes}


def main() -> None:
    out = Path("results/finite-shots")
    out.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEED)
    runs = {d: simulate(d, rng) for d in (4, 8, 16)}

    fig, axes = plt.subplots(3, 2, figsize=(12, 12), constrained_layout=True)
    for row, (d, run) in enumerate(runs.items()):
        spec = run["design"]
        ax = axes[row, 0]
        ax.plot(run["x"] / np.pi, run["exact"], color="black", lw=1.5, label="analytic")
        ax.scatter(run["x"] / np.pi, run["sampled"], s=9, alpha=.65, label="finite shots")
        ax.set(title=f"d={d}: purity ({spec['partitions']} partitions, {spec['shots_per_partition']:,} shots)",
               xlabel=r"$\omega t/\pi$", ylabel=r"$\mathrm{Tr}(\rho_A^2)$")
        ax.grid(alpha=.25); ax.legend()

        ax = axes[row, 1]
        modes = np.arange(2, 2 * (d - 1) + 1)
        ax.plot(modes, run["exact_modes"][modes], "o-", color="black", ms=3, label="analytic")
        ax.scatter(modes, run["sampled_modes"][modes], s=20, label="finite shots")
        prime_modes = np.array([n for n in modes if is_prime(int(n))])
        ax.scatter(prime_modes, run["sampled_modes"][prime_modes], marker="o", facecolors="none",
                   edgecolors="tab:red", s=65, label="prime")
        ax.set(title=f"d={d}: recovered Fourier modes", xlabel="mode n", ylabel=r"$\alpha_n$")
        ax.grid(alpha=.25); ax.legend()
    fig.suptitle("Finite-shot PIED simulation (seed 20260919)", fontsize=15)
    fig.savefig(out / "finite-shot-pied-d4-d8-d16.png", dpi=180)
    fig.savefig(out / "finite-shot-pied-d4-d8-d16.pdf")
    plt.close(fig)

    summary = {}
    for d, run in runs.items():
        modes = np.arange(2, 2 * (d - 1) + 1)
        errors = np.abs(run["sampled_modes"][modes] - run["exact_modes"][modes])
        summary[str(d)] = {**run["design"], "seed": SEED,
                           "maximum_observed_mode_error": float(np.max(errors))}
        with (out / f"d{d}.csv").open("w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(["omega_t_over_pi", "analytic_purity", "finite_shot_purity"])
            writer.writerows(zip(run["x"] / np.pi, run["exact"], run["sampled"]))
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()

